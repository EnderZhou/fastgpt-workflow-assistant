#!/usr/bin/env python3
"""把 Skill 打包为可导入 ZIP，确保 SKILL.md 位于压缩包根目录。"""

from __future__ import annotations

import argparse
import zipfile
from pathlib import Path


EXCLUDED_PARTS = {"__pycache__", ".git", ".DS_Store"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("skill_directory", type=Path)
    parser.add_argument("output_zip", type=Path)
    parser.add_argument("--force", action="store_true", help="覆盖已存在的目标ZIP")
    return parser.parse_args()


def should_include(path: Path, root: Path) -> bool:
    relative = path.relative_to(root)
    if any(part in EXCLUDED_PARTS for part in relative.parts):
        return False
    return path.suffix.lower() != ".pyc"


def package(skill_directory: Path, output_zip: Path, force: bool = False) -> tuple[int, int]:
    root = skill_directory.resolve()
    output = output_zip.resolve()
    if not root.is_dir():
        raise NotADirectoryError(root)
    if not (root / "SKILL.md").is_file():
        raise FileNotFoundError(f"SKILL.md not found: {root}")
    if output.exists() and not force:
        raise FileExistsError(f"refusing to overwrite existing package: {output}")
    if root == output.parent or root in output.parents:
        raise ValueError("output ZIP must be outside the skill directory")
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()

    files = sorted(path for path in root.rglob("*") if path.is_file() and should_include(path, root))
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            archive.write(path, path.relative_to(root).as_posix())

    with zipfile.ZipFile(output, "r") as archive:
        names = archive.namelist()
        if "SKILL.md" not in names:
            raise RuntimeError("package validation failed: SKILL.md is not at ZIP root")
        if any(name.startswith(root.name + "/") for name in names):
            raise RuntimeError("package validation failed: unexpected outer skill directory")
        archive.testzip()
    return len(files), output.stat().st_size


def main() -> int:
    args = parse_args()
    try:
        count, size = package(args.skill_directory, args.output_zip, force=args.force)
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}")
        return 1
    print(f"OK: {args.output_zip.resolve()}")
    print(f"FILES: {count}")
    print(f"SIZE: {size}")
    print("ROOT_ENTRY: SKILL.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
